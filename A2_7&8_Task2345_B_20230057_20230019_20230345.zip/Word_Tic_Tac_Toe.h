#pragma once

#ifndef Word_Tic_Tac_Toe_H
#define Word_Tic_Tac_Toe_H

#include "BoardGame_Classes.h"

template <typename T>
class Word_Tic_Tac_Toe_Board :public Board<T> {
public:
    Word_Tic_Tac_Toe_Board();
    bool update_board(int x, int y, T symbol);
    void display_board();
    bool is_win();
    bool is_draw();
    bool game_is_over();
    vector <string> LoadFromFile();
    bool IsValidWord(vector <string> res, string Test);

};

template <typename T>
class Word_Tic_Tac_Toe_Player : public Player<T> {

public:

    Word_Tic_Tac_Toe_Player(string name, T Test);

    void getmove(int& x, int& y);

    void getsymbol();

};

template <typename T>
class Word_Tic_Tac_Toe_Random_Player : public RandomPlayer<T> {
public:
    Word_Tic_Tac_Toe_Random_Player(T symbol);
    void getmove(int& x, int& y);

};

template <typename T>
class Word_Tic_Tac_Toe_Game_Manager : public GameManager<T>
{
protected:
    Board<T>* boardPtr;
    Player<T>* players[2];

public:
    Word_Tic_Tac_Toe_Game_Manager(Word_Tic_Tac_Toe_Board<T>* board, Player<T>* playerPtr[2])
        : GameManager<T>(board, playerPtr)
    {
        boardPtr = board;
        players[0] = playerPtr[0];
        players[1] = playerPtr[1];
    }

    void Word_Tic_Tac_Toe_run();
};

//--------------------------------------- IMPLEMENTATION

#include <iostream>
#include <iomanip>
#include <vector>
#include <fstream>
#include <cctype>
#include <string>
#include <algorithm>

using namespace std;

template <typename T>
Word_Tic_Tac_Toe_Board<T>::Word_Tic_Tac_Toe_Board() {
    this->rows = this->columns = 3;
    this->board = new char* [this->rows];
    for (int i = 0; i < this->rows; i++) {
        this->board[i] = new char[this->columns];
        for (int j = 0; j < this->columns; j++) {
            this->board[i][j] = 0;
        }
    }
    this->n_moves = 0;
}

template <typename T>
bool Word_Tic_Tac_Toe_Board<T>::update_board(int x, int y, T mark) {
    // Only update if move is valid
    if (!(x < 0 || x >= this->rows || y < 0 || y >= this->columns) && (this->board[x][y] == 0 || mark == 0)) {
        if (mark == 0) {
            this->n_moves--;
            this->board[x][y] = 0;
        }
        else {
            this->n_moves++;
            this->board[x][y] = toupper(mark);
        }

        return true;
    }
    return false;
}

// Display the board and the pieces on it
template <typename T>
void Word_Tic_Tac_Toe_Board<T>::display_board() {
    for (int i = 0; i < this->rows; i++) {
        cout << "\n| ";
        for (int j = 0; j < this->columns; j++) {
            cout << "(" << i << "," << j << ")";
            cout << setw(5) << right << this->board[i][j] << " |";
        }
        cout << "\n-------------------------------------";
    }
    cout << endl;
}

template <typename T>
vector <string> Word_Tic_Tac_Toe_Board<T>::LoadFromFile()
{
    vector <string> Result;

    fstream file;
    file.open("dic.txt", ios::in);

    if (!file.is_open()) {
        cerr << "Error: Unable to open dictionary file.\n";
        return Result;
    }

    if (file.is_open())
    {

        string line;

        while (getline(file, line)) {

            Result.push_back(line);
        }

        file.close();
    }

    return Result;
}

template <typename T>
bool Word_Tic_Tac_Toe_Board<T>::IsValidWord(vector <string> res, string Test)
{
    string ReversedOne = Test;
    reverse(ReversedOne.begin(), ReversedOne.end());

    for (string& i : res)
    {
        if (Test == i || ReversedOne == i)
        {
            return true;
        }

    }

    return false;
}

// Returns true if there is any winner
template <typename T>
bool Word_Tic_Tac_Toe_Board<T>::is_win()
{
    vector <string> Result = LoadFromFile();

    if (this->n_moves >= 2)
    {
        string TheMeanWord1 = "";
        string TheMeanWord2 = "";

        for (int i = 0; i < this->rows; i++) {
            if ((this->board[i][0] != 0 && this->board[i][1] != 0 && this->board[i][2] != 0) ||
                (this->board[0][i] != 0 && this->board[1][i] != 0 && this->board[2][i] != 0)) {

                TheMeanWord1 = string(1, this->board[i][0]) + this->board[i][1] + this->board[i][2];
                TheMeanWord2 = string(1, this->board[0][i]) + this->board[1][i] + this->board[2][i];

                return (IsValidWord(Result, TheMeanWord1) || IsValidWord(Result, TheMeanWord2));
            }
        }

        // Check diagonals
        if ((this->board[0][0] != 0 && this->board[1][1] != 0 && this->board[2][2] != 0) ||
            (this->board[0][2] != 0 && this->board[1][1] != 0 && this->board[2][0] != 0)) {

            TheMeanWord1 = string(1, this->board[0][0]) + this->board[1][1] + this->board[2][2];
            TheMeanWord2 = string(1, this->board[0][2]) + this->board[1][1] + this->board[2][0];

            return (IsValidWord(Result, TheMeanWord1) || IsValidWord(Result, TheMeanWord2));
        }
    }

    return false;
}

// Return true if 9 moves are done and no winner
template <typename T>
bool Word_Tic_Tac_Toe_Board<T>::is_draw() {
    return (this->n_moves == 9 && !is_win());
}

template <typename T>
bool Word_Tic_Tac_Toe_Board<T>::game_is_over() {
    return is_win() || is_draw();
}

//--------------------------------------

template <typename T>
Word_Tic_Tac_Toe_Player<T>::Word_Tic_Tac_Toe_Player(string name, T Test) : Player<T>(name, Test) {}

template <typename T>
void Word_Tic_Tac_Toe_Player<T>::getsymbol()
{
    char Test;
    cout << "Enter Your Character : ";
    cin >> Test;
}

template <typename T>
void Word_Tic_Tac_Toe_Player<T>::getmove(int& x, int& y) {
    cout << "\nPlease enter your move x and y (0 to 2) separated by spaces: ";
    cin >> x >> y;

    cout << "Enter your character : ";
    cin >> this->symbol;
}

template <typename T>
Word_Tic_Tac_Toe_Random_Player<T>::Word_Tic_Tac_Toe_Random_Player(T symbol) : RandomPlayer<T>(symbol) {
    this->dimension = 3;
    this->name = "Random Computer Player";
    srand(static_cast<unsigned int>( time(0) ));
}

template <typename T>
void Word_Tic_Tac_Toe_Random_Player<T>::getmove(int& x, int& y) {
    x = rand() % this->dimension;
    y = rand() % this->dimension;
}

template <typename T>
void Word_Tic_Tac_Toe_Game_Manager<T>::Word_Tic_Tac_Toe_run()
{
    int x, y;

    boardPtr->display_board();

    while (!boardPtr->game_is_over()) {
        for (int i : {0, 1}) {
            players[i]->getmove(x, y);

            while (!boardPtr->update_board(x, y, players[i]->getsymbol())) {
                players[i]->getmove(x, y);
            }
            boardPtr->display_board();
            if (boardPtr->is_win()) {
                cout << players[i]->getname() << " wins\n";
                return;
            }
            if (boardPtr->is_draw()) {
                cout << "Draw!\n";
                return;
            }

        }
    }
}

void Start3()
{
    int choice;
    Player<char>* players[2];
    Word_Tic_Tac_Toe_Board<char>* B = new Word_Tic_Tac_Toe_Board<char>();
    string playerXName, player2Name;

    cout << "Welcome to FCAI 5x5_Tic_Tac_Toe Game. :)\n";

    // Set up player 1
    cout << "Enter Player X name: ";
    cin >> playerXName;
    cout << "Choose Player X type:\n";
    cout << "1. Human\n";
    cout << "2. Random Computer\n";
    cin >> choice;

    switch (choice) {
    case 1:
        players[0] = new Word_Tic_Tac_Toe_Player<char>(playerXName, 'X');
        break;
    case 2:
        players[0] = new Word_Tic_Tac_Toe_Random_Player<char>('X');
        break;
    default:
        cout << "Invalid choice for Player 1. Exiting the game.\n";
        return;
    }

    // Set up player 2
    cout << "Enter Player 2 name: ";
    cin >> player2Name;
    cout << "Choose Player 2 type:\n";
    cout << "1. Human\n";
    cout << "2. Random Computer\n";
    cin >> choice;

    switch (choice) {
    case 1:
        players[1] = new Word_Tic_Tac_Toe_Player<char>(player2Name, 'O');
        break;

    case 2:
        players[1] = new Word_Tic_Tac_Toe_Random_Player<char>('O');
        break;

    default:
        cout << "Invalid choice for Player 2. Exiting the game.\n";
        return;
    }

    Word_Tic_Tac_Toe_Game_Manager<char> Word_Tic_Tac_Toe(B, players);
    Word_Tic_Tac_Toe.Word_Tic_Tac_Toe_run();

    delete B;
    for (int i = 0; i < 2; ++i) {
        if (players[i] != nullptr) {
            delete players[i];
        }
    }

}

#endif