//
// Created by SIGMA on 12/8/2024.
//

#ifndef UNTITLED8_FOUR_IN_A_ROW_H
#define UNTITLED8_FOUR_IN_A_ROW_H
#include "BoardGame_Classes.h"

template <typename T> // Methods
class four_in_a_row_Board:public Board<T> {
public:
    four_in_a_row_Board ();
    bool update_board (int x,int y, T symbol);
    void display_board () ;
    bool is_win() ;
    bool is_draw();
    bool game_is_over();

};

template <typename T> // player++
class four_in_a_row_Player : public Player<T> {
public:
    four_in_a_row_Player (string name, T symbol);
    void getmove(int& x,int& y) ;

};

template <typename T> // random player ++
class four_in_a_row_Random_Player : public RandomPlayer<T>{
public:
    four_in_a_row_Random_Player (T symbol);
    void getmove(int &x,int &y);
};





//--------------------------------------- IMPLEMENTATION

#include <iostream>
#include <iomanip>
#include <cctype>

using namespace std;
template <typename T>
four_in_a_row_Board<T>::four_in_a_row_Board()
{ // demantion
    this->rows = 6;
    this->columns = 7;
    this->board = new char*[this->rows];
    for (int i = 0; i < this->rows; i++) {
        this->board[i] = new char[this->columns];
        for (int j = 0; j < this->columns; j++) {
            this->board[i][j] = 0;
        }
    }
    this->n_moves = 0;
}

template <typename T>
bool four_in_a_row_Board<T>::update_board(int x, int y, T symbol) {
    // ignore y
    if (x < 0 || x >= this->columns) { // cheak
        return false;
    }

    // search
    for (int row = this->rows - 1; row >= 0; --row) {
        if (this->board[row][x] == 0) { // if empty
            this->board[row][x] = toupper(symbol); // put mark
            this->n_moves++; // update # moves
            return true;
        }
    }

    return false; // if full
}


template <typename T>
void four_in_a_row_Board<T>::display_board() {
    for (int i = 0; i < this->rows; i++) {
        cout << "\n| ";
        for (int j = 0; j < this->columns; j++) {
            cout << "(" << i << "," << j << ")";
            cout << setw(2) << this->board[i][j] << " |";
        }
        cout << "\n-------------------------------------------------------------";
    }
    cout << endl;
}

template <typename T>
bool four_in_a_row_Board<T>::is_win() {
    // check
    for (int i = 0; i < this->rows; i++) {
        for (int j = 0; j <= this->columns - 4; j++) {
            if (this->board[i][j] != 0 &&
                this->board[i][j] == this->board[i][j + 1] &&
                this->board[i][j] == this->board[i][j + 2] &&
                this->board[i][j] == this->board[i][j + 3]) {
                return true; // وجدنا فائزاً
            }
        }
    }

// chea;
    for (int i = 0; i <= this->rows - 4; i++) {
        for (int j = 0; j < this->columns; j++) {
            if (this->board[i][j] != 0 &&
                this->board[i][j] == this->board[i + 1][j] &&
                this->board[i][j] == this->board[i + 2][j] &&
                this->board[i][j] == this->board[i + 3][j]) {
                return true; // winner
            }
        }
    }

// cheak
    for (int i = 0; i <= this->rows - 4; i++) {
        for (int j = 0; j <= this->columns - 4; j++) {
            if (this->board[i][j] != 0 &&
                this->board[i][j] == this->board[i + 1][j + 1] &&
                this->board[i][j] == this->board[i + 2][j + 2] &&
                this->board[i][j] == this->board[i + 3][j + 3]) {
                return true; // wineer
            }
        }
    }

// cheak
    for (int i = 0; i <= this->rows - 4; i++) {
        for (int j = 3; j < this->columns; j++) {
            if (this->board[i][j] != 0 &&
                this->board[i][j] == this->board[i + 1][j - 1] &&
                this->board[i][j] == this->board[i + 2][j - 2] &&
                this->board[i][j] == this->board[i + 3][j - 3]) {
                return true; // winner
            }
        }
    }

    return false; // no winner

}

template <typename T>
bool four_in_a_row_Board<T>::is_draw() {
    return (this->n_moves == 42 && !is_win());
}

template <typename T>
bool four_in_a_row_Board<T>::game_is_over() {
    return is_win() || is_draw();
}

template <typename T>
four_in_a_row_Player<T>::four_in_a_row_Player(string name, T symbol) : Player<T>(name, symbol) {}

template <typename T>
void four_in_a_row_Player<T>::getmove(int& x,int& y) {
    cout << this->getname() << ", enter column (0 to 6) : ";
    cin >> x;
    y = 0;
}
template <typename T>
four_in_a_row_Random_Player<T>::four_in_a_row_Random_Player(T symbol) : RandomPlayer<T>(symbol) {
    this->dimension = 7;
    this->name = "Random Computer Player";
    srand(static_cast<unsigned int>(time(0)));
}

template <typename T>
void four_in_a_row_Random_Player<T>::getmove(int& x,int& y) {
    x = rand() % this->dimension;
}


#endif //UNTITLED8_FOUR_IN_A_ROW_H