
#ifndef NUMERICAL_3X3X_O_H
#define NUMERICAL_3X3X_O_H

#include "BoardGame_Classes.h"

template <typename T>
class numerical_Board:public Board<T> {
private: // vectors player choose from it
    vector<int>numbesr_odd = {1,3,5,7,9}; // player odd
    vector<int>numbesr_even = {2,4,6,8}; // player even

public: // Methods
    numerical_Board ();
    bool update_board (int x , int y , T symbol);
    void display_board () ;
    bool is_win() ;
    bool is_draw();
    bool game_is_over();


};

template <typename T>
class numerical_Player : public Player<T> { //inherted+
public:
    numerical_Player (string name, T symbol);
    void getmove(int& x, int& y) ;

};

template <typename T>
class numerical_Random_Player : public RandomPlayer<T>{ //inherted+
public:
    numerical_Random_Player (T symbol);
    void getmove(int &x, int &y) ;
};





//--------------------------------------- IMPLEMENTATION

#include <iostream>
#include <iomanip>
#include <cctype>
#include <algorithm>
#include <random>

using namespace std;

// Constructors for numerical_X_O_Board
template <typename T>
numerical_Board<T>::numerical_Board() {
    this->rows = this->columns = 3; //demaions
    this->board = new char*[this->rows];
    for (int i = 0; i < this->rows; i++) {
        this->board[i] = new char[this->columns];
        for (int j = 0; j < this->columns; j++) {
            this->board[i][j] = 0;
        }
    }
    this->n_moves = 0;
}

template <typename T>
bool numerical_Board<T>::update_board(int x, int y, T mark) {
    // Only update if move is valid
    if (x == -1 && y == -1) { // if random player
        do {
            x = rand() % 3;
            y = rand() % 3;
        } while (this->board[x][y] != 0);

        int num;
        if (mark == 'X') { // if odd player
            num = numbesr_odd[rand() % numbesr_odd.size()];
            this->board[x][y] = static_cast<char>(num + '0');
            numbesr_odd.erase(remove(numbesr_odd.begin(), numbesr_odd.end(), num), numbesr_odd.end());
        } else { // if even player
            num = numbesr_even[rand() % numbesr_even.size()];
            this->board[x][y] = static_cast<char>(num + '0');
            numbesr_even.erase(remove(numbesr_even.begin(), numbesr_even.end(), num), numbesr_even.end());
        }
        return true;
    }
    else // if human player
    {
        if (!(x < 0 || x >= this->rows || y < 0 || y >= this->columns) && (this->board[x][y] == 0|| mark == 0)) {//cheak
            if (mark == 0){
                this->n_moves--;
                this->board[x][y] = 0;
            }
            else {
                this->n_moves++;
                if(toupper(mark) == 'X')//if odd player
                {

                    int num;
                    cout << "Enter Your odd Number from ";
                    for(int nu : numbesr_odd){cout << nu <<" : ";}
                    cin>>num;
                    while(!(count(numbesr_odd.begin(),numbesr_odd.end(),num))) // cheak
                    {
                        cout << "Your number not valid, Try Again : ";
                        cin >>num;
                    }
                    this->board[x][y] = num + 48;
                    numbesr_odd.erase(remove(numbesr_odd.begin(),numbesr_odd.end(),num));// to remove from vector
                }
                else
                {
                    int num;
                    cout << "Enter Your even Number from ";
                    for(int nu : numbesr_even){cout << nu <<" : ";}
                    cin>>num;
                    while(!(count(numbesr_even.begin(),numbesr_even.end(),num)))// cheak
                    {
                        cout << "Your number not valid, Try Again : ";
                        cin >>num;
                    }

                    this->board[x][y] = num + 48;
                    numbesr_even.erase(remove(numbesr_even.begin(),numbesr_even.end(),num));// to remove from vector

                }


            }

            return true;
        }
    }

    return false;
}


template <typename T>
void numerical_Board<T>::display_board() {
    for (int i = 0; i < this->rows; i++) {
        cout << "\n| ";
        for (int j = 0; j < this->columns; j++) {
            cout << "(" << i << "," << j << ")";
            cout << setw(2) << this->board[i][j] << " |";
        }
        cout << "\n-----------------------------";
    }
    cout << endl;
}

// Returns true if there is any winner
template <typename T>
bool numerical_Board<T>::is_win() { // cheak if win
    // Check rows and columns
    for (int i = 0; i < this->rows; i++) {
        if ((int(this->board[i][0] - '0') + int(this->board[i][1] - '0') + int(this->board[i][2] - '0') == 15 && this->board[i][0] != 0) ||
            (int(this->board[0][i] - '0') + int(this->board[1][i] - '0') + int(this->board[2][i] - '0') == 15 && this->board[0][i] != 0)) {
            return true;
        }
    }

    // Check diagonals
    if ((int(this->board[0][0] - '0') + int(this->board[1][1] - '0') + int(this->board[2][2] - '0') == 15 && this->board[0][0] != 0) ||
        (int(this->board[0][2] - '0') + int(this->board[1][1] - '0') + int(this->board[2][0] - '0') == 15 && this->board[0][2] != 0)) {
        return true;
    }

    return false;
}

// cheak if Drow
template <typename T>
bool numerical_Board<T>::is_draw() {
    return (this->n_moves == 9 && !is_win());
}

template <typename T> // cheak if gameover
bool numerical_Board<T>::game_is_over() {
    return is_win() || is_draw();
}

//--------------------------------------

// Constructor for numerical_X_O_Player
template <typename T>
numerical_Player<T>::numerical_Player(string name, T symbol) : Player<T>(name, symbol) {}

template <typename T>
void numerical_Player<T>::getmove(int& x, int& y) {
    cout << "\nPlease enter your move x and y (0 to 2) separated by spaces: ";
    cin >> x >> y;
}

// Constructor for X_O_Random_Player
template <typename T>
numerical_Random_Player<T>::numerical_Random_Player(T symbol) : RandomPlayer<T>(symbol) {
    this->dimension = 3;
    this->name = "Random Computer Player";
    srand(static_cast<unsigned int>(time(0)));  // Seed the random number generator
}

template <typename T>
void numerical_Random_Player<T>::getmove(int& x, int& y) {
    x = -1;  // Random number between 0 and 2
    y = -1;
}







#endif //NUMERICAL_3X3X_O_H

