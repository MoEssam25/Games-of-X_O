#pragma once

#ifndef _5x5_Tic_Tac_Toe_H
#define _5x5_Tic_Tac_Toe_H

#include "BoardGame_Classes.h"

int num_of_F = 0;
int num_of_S = 0;

template <typename T>
class _5x5_Tic_Tac_Toe_Board :public Board<T> {
public:
    _5x5_Tic_Tac_Toe_Board();
    bool update_board(int x, int y, T symbol);
    void display_board();
    bool is_win();
    bool is_draw();
    bool game_is_over();

};

template <typename T>
class _5x5_Tic_Tac_Toe_Player : public Player<T> {
public:
    _5x5_Tic_Tac_Toe_Player(string name, T symbol);
    void getmove(int& x, int& y);


};

template <typename T>
class _5x5_Tic_Tac_Toe_Random_Player : public RandomPlayer<T> {
public:
    _5x5_Tic_Tac_Toe_Random_Player(T symbol);
    void getmove(int& x, int& y);

};

template <typename T>
class _5x5_Tic_Tac_Toe_Game_Manager : public GameManager<T>
{
protected:
    Board<T>* boardPtr;
    Player<T>* players[2];

public:
    _5x5_Tic_Tac_Toe_Game_Manager(_5x5_Tic_Tac_Toe_Board<T>* board, Player<T>* playerPtr[2])
        : GameManager<T>(board, playerPtr)
    {
        boardPtr = board;
        players[0] = playerPtr[0];
        players[1] = playerPtr[1];
    }

    void _5x5_Tic_Tac_Toe_run();
};

//--------------------------------------- IMPLEMENTATION

#include <iostream>
#include <iomanip>
#include <cctype>

using namespace std;

template <typename T>
_5x5_Tic_Tac_Toe_Board<T>::_5x5_Tic_Tac_Toe_Board() {
    this->rows = this->columns = 5;
    this->board = new char* [this->rows];
    for (int i = 0; i < this->rows; i++) {
        this->board[i] = new char[this->columns];
        for (int j = 0; j < this->columns; j++) {
            this->board[i][j] = 0;
        }
    }
    this->n_moves = 0;
}

template <typename T>
bool _5x5_Tic_Tac_Toe_Board<T>::update_board(int x, int y, T mark) {
    // Only update if move is valid
    if (!(x < 0 || x >= this->rows || y < 0 || y >= this->columns) && (this->board[x][y] == 0 || mark == 0)) {
        if (mark == 0) {
            this->n_moves--;
            this->board[x][y] = 0;
        }
        else {
            this->n_moves++;
            this->board[x][y] = toupper(mark);
        }

        return true;
    }
    return false;
}

// Display the board and the pieces on it
template <typename T>
void _5x5_Tic_Tac_Toe_Board<T>::display_board() {
    for (int i = 0; i < this->rows; i++) {
        cout << "\n| ";
        for (int j = 0; j < this->columns; j++) {
            cout << "(" << i << "," << j << ")";
            cout << setw(5) << right << this->board[i][j] << " |";
        }
        cout << "\n----------------------------------------------------------";
    }
    cout << endl;
}

int count_three_in_a_rows(char** T, char player) {
    int count = 0;
    const int n = 5;

    // Rows
    for (int j = 0; j < n; j++) {
        for (int i = 0; i <= 2; i++) {
            if (T[i][j] == player && T[i][j + 1] == player && T[i][j + 2] == player) {
                count++;
            }
        }
    }

    for (int j = 0; j < n; j++) {
        for (int i = 1; i <= 3; i++) {
            if (T[i][j] == player && T[i][j + 1] == player && T[i][j + 2] == player) {
                count++;
            }
        }
    }

    for (int j = 0; j < n; j++) {
        for (int i = 2; i <= 4; i++) {
            if (T[i][j] == player && T[i][j + 1] == player && T[i][j + 2] == player) {
                count++;
            }
        }
    }

    // Cols
    for (int j = 0; j < n; j++) {
        for (int i = 0; i <= 2; i++) {
            if (T[i][j] == player && T[i + 1][j] == player && T[i + 2][j] == player) {
                count++;
            }
        }
    }
    
    // Diagonals
    for (int i = 0; i <= 5 - 3; i++) {
        for (int j = 0; j <= 5 - 3; j++) {
            if (T[i][j] == player && T[i + 1][j + 1] == player && T[i + 2][j + 2] == player) {
                count++;
            }
        }
    }

    // Check diagonals (bottom-left to top-right)
    for (int i = 3 - 1; i < 5; i++) {
        for (int j = 0; j <= 5 - 3; j++) {
            if (T[i][j] == player && T[i - 1][j + 1] == player && T[i - 2][j + 2] == player) {
                count++;
            }
        }
    }

    return count;
}

// Returns true if there is any winner
template <typename T>
bool _5x5_Tic_Tac_Toe_Board<T>::is_win() {

    num_of_F = count_three_in_a_rows(this->board, 'X');
    num_of_S = count_three_in_a_rows(this->board, 'O');

    return (((num_of_S > num_of_F) || (num_of_S < num_of_F)) && (num_of_S != 0) && (this->n_moves == 24));
}

// Return true if 9 moves are done and no winner
template <typename T>
bool _5x5_Tic_Tac_Toe_Board<T>::is_draw() {
    return (this->n_moves == 24 && (num_of_S == num_of_F));
}

template <typename T>
bool _5x5_Tic_Tac_Toe_Board<T>::game_is_over() {
    return is_win() || is_draw();
}

//--------------------------------------

template <typename T>
_5x5_Tic_Tac_Toe_Player<T>::_5x5_Tic_Tac_Toe_Player(string name, T symbol) : Player<T>(name, symbol) {}

template <typename T>
void _5x5_Tic_Tac_Toe_Player<T>::getmove(int& x, int& y) {
    cout << "\nPlease enter your move x and y (0 to 2) separated by spaces: ";
    cin >> x >> y;
}

template <typename T>
_5x5_Tic_Tac_Toe_Random_Player<T>::_5x5_Tic_Tac_Toe_Random_Player(T symbol) : RandomPlayer<T>(symbol) {
    this->dimension = 5;
    this->name = "Random Computer Player";
    srand(static_cast<unsigned int>(time(0)));  // Seed the random number generator
}

template <typename T>
void _5x5_Tic_Tac_Toe_Random_Player<T>::getmove(int& x, int& y) {
    x = rand() % this->dimension;
    y = rand() % this->dimension;
}

template <typename T>
void _5x5_Tic_Tac_Toe_Game_Manager<T>::_5x5_Tic_Tac_Toe_run()
{
    int x, y;

    boardPtr->display_board();

    while (!boardPtr->game_is_over()) {

        for (int i : {0, 1}) {
            players[i]->getmove(x, y);

            while (!boardPtr->update_board(x, y, players[i]->getsymbol())) {
                players[i]->getmove(x, y);
            }
            boardPtr->display_board();
        }
    }

    if (boardPtr->is_win()) {
        if ((num_of_S < num_of_F))
        {
            cout << players[0]->getname() << " wins\n";
            num_of_S = 0;
            num_of_F = 0;
            return;
        }
        else if (num_of_S > num_of_F)
        {
            cout << players[1]->getname() << " wins\n";
            return;
        }
    }
    else if (boardPtr->is_draw()) {
        cout << "Draw!\n";
        return;
    }

}

void Start2()
{
    int choice;
    Player<char>* players[2];
    _5x5_Tic_Tac_Toe_Board<char>* B = new _5x5_Tic_Tac_Toe_Board<char>();
    string playerXName, player2Name;

    cout << "Welcome to FCAI 5x5_Tic_Tac_Toe Game. :)\n";

    // Set up player 1
    cout << "Enter Player X name: ";
    cin >> playerXName;
    cout << "Choose Player X type:\n";
    cout << "1. Human\n";
    cout << "2. Random Computer\n";
    cin >> choice;

    switch (choice) {
    case 1:
        players[0] = new _5x5_Tic_Tac_Toe_Player<char>(playerXName, 'X');
        break;
    case 2:
        players[0] = new _5x5_Tic_Tac_Toe_Random_Player<char>('X');
        break;
    default:
        cout << "Invalid choice for Player 1. Exiting the game.\n";
        return;
    }

    // Set up player 2
    cout << "Enter Player 2 name: ";
    cin >> player2Name;
    cout << "Choose Player 2 type:\n";
    cout << "1. Human\n";
    cout << "2. Random Computer\n";
    cin >> choice;

    switch (choice) {
    case 1:
        players[1] = new _5x5_Tic_Tac_Toe_Player<char>(player2Name, 'O');
        break;
    case 2:
        players[1] = new _5x5_Tic_Tac_Toe_Random_Player<char>('O');
        break;
    default:
        cout << "Invalid choice for Player 2. Exiting the game.\n";
        return;
    }

    _5x5_Tic_Tac_Toe_Game_Manager<char> _5x5_Tic_Tac_Toe(B, players);
    _5x5_Tic_Tac_Toe._5x5_Tic_Tac_Toe_run();

    // Clean up
    delete B;
    for (int i = 0; i < 2; ++i) {
        delete players[i];
    }

}

#endif